SET FOREIGN_KEY_CHECKS=0;

CREATE DATABASE IF NOT EXISTS wisp_juan;

USE wisp_juan;

DROP TABLE IF EXISTS ap_clientes;

CREATE TABLE `ap_clientes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `ip` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci DEFAULT NULL,
  `version` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci DEFAULT NULL,
  `cam` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO ap_clientes VALUES("3","prueba","192.18.10.0","1","");



DROP TABLE IF EXISTS ap_emisor;

CREATE TABLE `ap_emisor` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `ip` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci DEFAULT NULL,
  `version` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;




DROP TABLE IF EXISTS ap_receptor;

CREATE TABLE `ap_receptor` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish2_ci NOT NULL,
  `ip` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci DEFAULT NULL,
  `version` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish2_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;




DROP TABLE IF EXISTS archivos;

CREATE TABLE `archivos` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `tipo` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `size` int NOT NULL,
  `ruta` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `tabla` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `object_id` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO archivos VALUES("2","Captura de pantalla 2024-11-04 140308.png","image/png","101232","Uploads/ap_clientes/3/Captura de pantalla 2024-11-04 140308.png","ap_clientes","3");



DROP TABLE IF EXISTS backups;

CREATE TABLE `backups` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `archive` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `size` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `registration_date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;




DROP TABLE IF EXISTS bills;

CREATE TABLE `bills` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `userid` bigint NOT NULL,
  `clientid` bigint NOT NULL,
  `voucherid` bigint NOT NULL,
  `serieid` bigint NOT NULL,
  `internal_code` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `correlative` bigint NOT NULL,
  `date_issue` date NOT NULL,
  `expiration_date` date NOT NULL,
  `billed_month` date NOT NULL,
  `subtotal` decimal(12,2) NOT NULL,
  `discount` decimal(12,2) NOT NULL,
  `total` decimal(12,2) NOT NULL,
  `amount_paid` decimal(12,2) NOT NULL,
  `remaining_amount` decimal(12,2) NOT NULL,
  `type` bigint NOT NULL,
  `sales_method` bigint NOT NULL,
  `observation` text CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `promise_enabled` tinyint NOT NULL,
  `promise_date` date DEFAULT NULL,
  `promise_set_date` date DEFAULT NULL,
  `promise_comment` varchar(512) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `state` bigint NOT NULL DEFAULT '2',
  PRIMARY KEY (`id`),
  KEY `serviceid` (`clientid`),
  KEY `userid` (`userid`),
  KEY `voucherid` (`voucherid`),
  KEY `serieid` (`serieid`),
  CONSTRAINT `bills_ibfk_3` FOREIGN KEY (`userid`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `bills_ibfk_5` FOREIGN KEY (`clientid`) REFERENCES `clients` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `bills_ibfk_6` FOREIGN KEY (`voucherid`) REFERENCES `vouchers` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `bills_ibfk_7` FOREIGN KEY (`serieid`) REFERENCES `voucher_series` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=82 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;

INSERT INTO bills VALUES("1","1","2","1","1","V00001","1","2025-03-13","2025-04-01","2025-03-01","31.00","0.00","31.00","31.00","0.00","2","2","","","2025-03-18","2025-03-13","por enfermedad","1");
INSERT INTO bills VALUES("2","1","2","1","1","V00002","2","2025-03-13","2025-05-01","2025-04-01","50.00","0.00","50.00","2.00","48.00","2","2","","","","","","2");
INSERT INTO bills VALUES("3","1","4","1","1","V00003","3","2025-03-13","2025-03-13","0000-00-00","500.00","0.00","500.00","500.00","0.00","1","2","","","","","","1");
INSERT INTO bills VALUES("4","1","4","1","1","V00004","4","2025-03-13","2025-04-01","2025-03-01","27.00","0.00","27.00","0.00","27.00","2","2","RAARA","","","","","3");
INSERT INTO bills VALUES("5","1","4","1","1","V00005","5","2025-03-14","2025-05-01","2025-04-01","50.00","0.00","50.00","1.00","49.00","2","2","","","","","","2");
INSERT INTO bills VALUES("6","1","4","1","1","V00006","6","2025-03-14","2025-06-01","2025-05-01","50.00","0.00","50.00","50.00","0.00","2","2","","","2025-03-31","2025-03-30","ok","1");
INSERT INTO bills VALUES("11","1","3","1","1","V00009","9","2025-03-28","2025-04-01","2025-03-01","33.30","0.00","33.30","33.30","0.00","2","2","","","","","adsfsfsd","1");
INSERT INTO bills VALUES("17","1","3","1","1","V00015","15","2025-04-02","2025-05-01","2025-04-01","50.00","0.00","50.00","50.00","0.00","2","2","","","","","","1");
INSERT INTO bills VALUES("18","1","3","1","1","V00016","16","2025-04-03","2025-06-01","2025-05-01","50.00","0.00","50.00","50.00","0.00","2","2","","","","","","1");
INSERT INTO bills VALUES("29","1","9","1","1","V00017","27","2025-04-07","2025-05-01","2025-04-01","19.00","0.00","19.00","19.00","0.00","2","2","","","","","","1");
INSERT INTO bills VALUES("80","1","9","1","1","V00018","48","2025-05-01","2025-06-01","2025-05-01","50.00","0.00","50.00","0.00","50.00","2","2","","","","","","2");
INSERT INTO bills VALUES("81","1","9","1","1","V00019","49","2025-06-01","2025-07-01","2025-06-01","50.00","0.00","50.00","50.00","0.00","2","2","","","","","","1");



DROP TABLE IF EXISTS business;

CREATE TABLE `business` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `documentid` bigint NOT NULL,
  `ruc` char(11) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `business_name` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `tradename` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `slogan` text CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `mobile` varchar(10) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `mobile_refrence` varchar(10) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `email` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `password` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `server_host` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `port` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `address` text CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `department` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `province` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `district` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `ubigeo` char(6) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `footer_text` text CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `currencyid` bigint NOT NULL,
  `print_format` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `logotyope` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `logo_login` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `logo_email` varchar(1000) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `favicon` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `country_code` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `google_apikey` text CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `reniec_apikey` text CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `background` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `whatsapp_api` varchar(100) COLLATE utf8mb4_spanish2_ci DEFAULT NULL,
  `whatsapp_key` varchar(100) COLLATE utf8mb4_spanish2_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `documentid` (`documentid`),
  KEY `currencyid` (`currencyid`),
  CONSTRAINT `business_ibfk_1` FOREIGN KEY (`documentid`) REFERENCES `document_type` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `business_ibfk_2` FOREIGN KEY (`currencyid`) REFERENCES `currency` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;

INSERT INTO business VALUES("4","1","132369076","NETWORK SRL","SUPORTEC NETWORK SRL","","8092969991","8092969991","facturas@suportecnetwork.com","Baldomera1991@#","mail.suportecnetwork.com","465","BONAO REP. DOM.","","BONAO","MONSENOR NOUEL","42000","","1","","","login_cbb53e6a0a41f6e6799c4d6f04daf9da.png","","favicon_3f7114e86862f23a1f4b9b1ed428921c.png","51","AIzaSyCqBa0JUtU2HSOYdpiKinJvJ4ZtjCEyjBw","604bf1d1bbe5e851c02259f51199f8a4240dd322252493d4fec0a47b9b6b005b1","bg-2.jpeg","https://api.then.net.pe","75116544");



DROP TABLE IF EXISTS business_wsp;

CREATE TABLE `business_wsp` (
  `id` varchar(100) COLLATE utf8mb4_spanish2_ci NOT NULL,
  `titulo` varchar(100) COLLATE utf8mb4_spanish2_ci DEFAULT NULL,
  `contenido` text COLLATE utf8mb4_spanish2_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;

INSERT INTO business_wsp VALUES("PAGO_MASSIVE","PAGOS MASIVOS","HOLA, {cliente}\n \n Se registró su pago de *{payment_total}*, al recibo de {payment_months}. \nMuchas gracias por su pago.\n\n Descargue su recibo en el siguiente enlace:\n{list_payments}\n\nAtte. {business_name}");
INSERT INTO business_wsp VALUES("SUPPORT_TECNICO","SOPORTE TECNICO","Buen dia, se genero el ticket Nº {ticket_num}, al cliente {cliente}, \nel tecnico se estara comunicando para solucionar el \ninconveniente con su servicio. \nMuchas gracias, \n\nAtte. {business_name}");
INSERT INTO business_wsp VALUES("PAYMENT_PENDING","PAGO PENDIENTE","Estimado cliente *{cliente}*, \nle recordamos que tiene una deuda *PENDIENTE* por el monto \n*TOTAL* de {debt_amount}, correspondiente a los siguientes *MESES:*\n\n{debt_list}\n\nGracias por formar parte de nuestra familia {business_name}, esperamos su pronto pago.\n\nAtte. {business_name}");
INSERT INTO business_wsp VALUES("PAYMENT_CONFIRMED","CONFIRMACIÓN DE PAGO","Hola, se registro {payment_total} al recibo número *{payment_num}* de \n*{payment_months}*, \nquedando un saldo pendiente de *{payment_pending}* del cliente {cliente}. \nPuede revisarlo en el siguiente enlace: \n\n{payment_links}\n\nMuchas gracias por su pago, \nAtte. {business_name}");
INSERT INTO business_wsp VALUES("CLIENT_ACTIVED","ACTIVAR CLIENTE","Hola {names}, Sus servicios fueron restaurados\nGracias {names}");
INSERT INTO business_wsp VALUES("CLIENT_SUSPENDED","SUSPENDER CLIENTE","‎Estimado cliente *{cliente}*\nsu servicio fue suspendido por falta de pago,\npor el monto adeudado de {debt} {debt_months}");
INSERT INTO business_wsp VALUES("CLIENT_CANCELLED","CANCELAR CLIENTE","‎Estimado cliente *{cliente}*\nsu servicio fue cancelado.\n\nAtte. {business_name}");



DROP TABLE IF EXISTS caja_nap;

CREATE TABLE `caja_nap` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish2_ci NOT NULL,
  `longitud` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `latitud` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `puertos` int NOT NULL,
  `detalles` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `ubicacion` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tipo` varchar(100) COLLATE utf8mb4_spanish2_ci NOT NULL DEFAULT 'nap',
  `color_tubo` varchar(100) COLLATE utf8mb4_spanish2_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;

INSERT INTO caja_nap VALUES("1","NAP 01","-74.5388981683731","-8.382424490194001","10","adsfa","asdfsaf","nap","");
INSERT INTO caja_nap VALUES("2","MUFA","-74.54016417102812","-8.383358540515633","12","dfd","asdfasdf","mufa","#ee1b1b");



DROP TABLE IF EXISTS caja_nap_clientes;

CREATE TABLE `caja_nap_clientes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nap_id` int NOT NULL,
  `puerto` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish2_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;

INSERT INTO caja_nap_clientes VALUES("17","1","1");
INSERT INTO caja_nap_clientes VALUES("18","1","2");
INSERT INTO caja_nap_clientes VALUES("19","1","3");
INSERT INTO caja_nap_clientes VALUES("20","1","4");
INSERT INTO caja_nap_clientes VALUES("21","1","5");
INSERT INTO caja_nap_clientes VALUES("22","1","6");
INSERT INTO caja_nap_clientes VALUES("23","1","7");
INSERT INTO caja_nap_clientes VALUES("24","1","8");
INSERT INTO caja_nap_clientes VALUES("25","1","9");
INSERT INTO caja_nap_clientes VALUES("26","1","10");
INSERT INTO caja_nap_clientes VALUES("27","2","1");
INSERT INTO caja_nap_clientes VALUES("28","2","2");
INSERT INTO caja_nap_clientes VALUES("29","2","3");
INSERT INTO caja_nap_clientes VALUES("30","2","4");
INSERT INTO caja_nap_clientes VALUES("31","2","5");
INSERT INTO caja_nap_clientes VALUES("32","2","6");
INSERT INTO caja_nap_clientes VALUES("33","2","7");
INSERT INTO caja_nap_clientes VALUES("34","2","8");
INSERT INTO caja_nap_clientes VALUES("35","2","9");
INSERT INTO caja_nap_clientes VALUES("36","2","10");
INSERT INTO caja_nap_clientes VALUES("37","2","11");
INSERT INTO caja_nap_clientes VALUES("38","2","12");



DROP TABLE IF EXISTS clients;

CREATE TABLE `clients` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `names` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `surnames` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `documentid` bigint NOT NULL,
  `document` varchar(15) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `mobile` varchar(10) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `mobile_optional` varchar(10) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `email` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `address` text CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `reference` text CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `note` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci DEFAULT NULL,
  `latitud` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `longitud` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `state` bigint NOT NULL DEFAULT '1',
  `net_router` int NOT NULL,
  `net_name` varchar(128) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `net_password` varchar(128) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `net_localaddress` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `net_ip` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `zonaid` bigint DEFAULT NULL,
  `ap_cliente_id` int DEFAULT NULL,
  `nap_cliente_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `documentid` (`documentid`),
  CONSTRAINT `clients_ibfk_1` FOREIGN KEY (`documentid`) REFERENCES `document_type` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;

INSERT INTO clients VALUES("1","PUBLICO","GENERAL","2","00000000","000000000","","","","","","","","1","","","","","","","","");
INSERT INTO clients VALUES("2","NADA","ADA","4","75116544","999220735","","","DSDS","","","-12.0520704","-77.0244608","1","","","","","","","","");
INSERT INTO clients VALUES("3","WALTER JUNIOR","RENDOS","2","75116543","3232","","","SDSD","","","18.9430487","-70.4131403","1","3","walter-junior-rendos","YSC+qjdyn+swfVrPXURRKE84NE0zRGVFOHJMYnFSei9FNTZyb2c9PQ==","192.168.18.1","192.168.18.11","","","");
INSERT INTO clients VALUES("4","JUAN","BERTRE","2","22222222","928237596","78570344","suportecnetwork@gmail.com","DIRECCION","REFERENCIA","NOTA ES","18.9430492","-70.4131402","1","3","juan-bertre","P4lhBC9fzn23+41C5tvpMkpFZHk2dEN0YmFpYWtGRkxOV0RsR2g1TXd2bytSL0k1UjNxSTMzSGJZRmM9","10.66.3.1","10.66.3.214","","","18");
INSERT INTO clients VALUES("5","JUNIOR","REES","2","32232","3434","43243","","DSDEW","REFE","NUT","","","1","2","junior-rees","e/3IxPHInK1nF5yDjVYACFh0enlSWGhXR2NTaEQ4blhHN3dLN3c9PQ==","192.168.18.1","192.168.18.3","","","");
INSERT INTO clients VALUES("6","OSCAR","RAM","1","6675567","7777","88888","","DUU","","","","","1","4","oscar-ram","6iM/szDEPmsJ1bC5/FKSzDJHWUhTSTZFbGYwUmhWQUdIUU5IOWc9PQ==","","172.16.10.117","","","");
INSERT INTO clients VALUES("7","YU","BER","2","534534","5654654","45345","","FFF","","","","","1","2","yu-ber","cmM/9RRu3SnX+fxDkp/z8294enZiQ2R1MVFmSkY5cE9QekZlcGc9PQ==","","192.168.18.40","","","");
INSERT INTO clients VALUES("8","YU","POOE","1","5345","543534","54545","","GFGDF","","","","","1","5","yu-pooe","vQMgethXvw2DGWtpee7+FzVOUm9wU3Q1VGYxbjFmMnkxSDRvY2RlbVo4UzZkL0dSVnNETTNRaEhmZjQ9","172.16.46.1","172.16.46.26","","","");
INSERT INTO clients VALUES("9","HANS","MEDINA","1","71051564","928237596","","twd2206@gmail.com","EN SU CASAA","AAA","ssss","","","1","2","hans-medinqqq","poAQKEj2LjSePWaCxQMkvG9wMm1jbmZ3ekwzUC9KcjJEd3dPS0E9PQ==","192.168.18.1","192.168.18.2","3","","");
INSERT INTO clients VALUES("10","HASN","DAFSAF","2","58555","4455","","twd2206@gmail.com","EN SU CASA","ASDFASFASDFDFDASF","","","","1","3","hasn-dafsaf","K6JykD75JGJNDZsCqb8FRktpOENlc0hxb1lqS0ExSCtuTThBYnZlWEU4R0tnV3ZkZ2EyNWxKZG1oSUU9","10.66.3.1","10.66.3.2","","","26");



DROP TABLE IF EXISTS contracts;

CREATE TABLE `contracts` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `userid` bigint NOT NULL,
  `clientid` bigint NOT NULL,
  `internal_code` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `payday` bigint NOT NULL,
  `create_invoice` bigint NOT NULL,
  `days_grace` bigint NOT NULL,
  `discount` bigint NOT NULL,
  `discount_price` decimal(12,2) NOT NULL,
  `months_discount` bigint NOT NULL,
  `remaining_discount` bigint NOT NULL,
  `contract_date` datetime NOT NULL,
  `suspension_date` date NOT NULL,
  `finish_date` date NOT NULL,
  `state` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `userid` (`userid`),
  KEY `clientid` (`clientid`),
  CONSTRAINT `contracts_ibfk_2` FOREIGN KEY (`userid`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `contracts_ibfk_3` FOREIGN KEY (`clientid`) REFERENCES `clients` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;

INSERT INTO contracts VALUES("1","1","2","CT00001","1","","5","","0.00","","","2025-03-11 12:31:30","2025-03-13","0000-00-00","3");
INSERT INTO contracts VALUES("2","1","3","CT00002","1","","5","","0.00","","","2025-03-13 20:01:25","2025-04-07","0000-00-00","4");
INSERT INTO contracts VALUES("3","1","4","CT00003","1","1","5","","0.00","","","2025-03-13 21:00:10","0000-00-00","0000-00-00","2");
INSERT INTO contracts VALUES("4","1","5","CT00004","1","","5","","0.00","","","2025-03-14 15:36:15","0000-00-00","0000-00-00","1");
INSERT INTO contracts VALUES("5","1","6","CT00005","1","","5","","0.00","","","2025-03-17 14:00:43","0000-00-00","0000-00-00","1");
INSERT INTO contracts VALUES("6","1","7","CT00006","1","","5","","0.00","","","2025-03-18 10:35:34","0000-00-00","0000-00-00","1");
INSERT INTO contracts VALUES("7","1","8","CT00007","1","","5","","0.00","","","2025-03-18 10:37:30","0000-00-00","0000-00-00","1");
INSERT INTO contracts VALUES("8","1","9","CT00008","1","","","","0.00","","","2025-03-18 16:31:25","0000-00-00","0000-00-00","3");
INSERT INTO contracts VALUES("9","1","10","CT00009","1","","","","0.00","","","2025-03-27 23:29:45","0000-00-00","0000-00-00","1");



DROP TABLE IF EXISTS cronjobs;

CREATE TABLE `cronjobs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `description` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `frequency` int NOT NULL,
  `parm` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `parmdesc` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `parmx` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `lastrun` int NOT NULL,
  `lastresult` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `code` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `status` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;

INSERT INTO cronjobs VALUES("1","Envía notificaciones a clientes con facturas próximas a vencer","30","","Días antes de expirar","%x% días antes","1742075162","Ejecuci&oacute;n autom&aacute;tica exitosa","IN001","1");
INSERT INTO cronjobs VALUES("2","Envía notificaciones a clientes con facturas vencidas","1440","","","","1737049735","Prueba exitosa","IN002","");
INSERT INTO cronjobs VALUES("3","Corta servicios a clientes con facturas vencidas","1440","","Días después de expirar","%x% días después","1737050361","Prueba exitosa","IN003","");
INSERT INTO cronjobs VALUES("4","Registra el tráfico de cada cliente","60","","","","1744119425","Prueba exitosa","CI001","1");
INSERT INTO cronjobs VALUES("5","Backup base de datos","43200","","Días antes de expirar","%x% días después","1744146046","Error en la ejecución (302)","IN004","1");



DROP TABLE IF EXISTS cronjobs_core;

CREATE TABLE `cronjobs_core` (
  `id` int NOT NULL AUTO_INCREMENT,
  `lastrun` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;

INSERT INTO cronjobs_core VALUES("1","1742076842");



DROP TABLE IF EXISTS cronjobs_exceptions;

CREATE TABLE `cronjobs_exceptions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `cronjobid` int NOT NULL,
  `clientid` int NOT NULL,
  `param_name` varchar(64) COLLATE utf8mb4_spanish2_ci NOT NULL,
  `param_value` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;




DROP TABLE IF EXISTS cronjobs_history;

CREATE TABLE `cronjobs_history` (
  `id` int NOT NULL AUTO_INCREMENT,
  `cronjobid` int NOT NULL,
  `result` varchar(128) COLLATE utf8mb4_spanish2_ci NOT NULL,
  `date` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=212 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;

INSERT INTO cronjobs_history VALUES("1","1","Ejecuci&oacute;n autom&aacute;tica exitosa","1741710181");
INSERT INTO cronjobs_history VALUES("2","4","Ejecuci&oacute;n autom&aacute;tica exitosa","1741710181");
INSERT INTO cronjobs_history VALUES("3","1","Ejecuci&oacute;n autom&aacute;tica exitosa","1741712042");
INSERT INTO cronjobs_history VALUES("4","4","Ejecuci&oacute;n autom&aacute;tica exitosa","1741713841");
INSERT INTO cronjobs_history VALUES("5","1","Ejecuci&oacute;n autom&aacute;tica exitosa","1741713902");
INSERT INTO cronjobs_history VALUES("6","1","Ejecuci&oacute;n autom&aacute;tica exitosa","1741715761");
INSERT INTO cronjobs_history VALUES("7","4","Ejecuci&oacute;n autom&aacute;tica exitosa","1741717442");
INSERT INTO cronjobs_history VALUES("8","1","Ejecuci&oacute;n autom&aacute;tica exitosa","1741717562");
INSERT INTO cronjobs_history VALUES("9","1","Ejecuci&oacute;n autom&aacute;tica exitosa","1741719422");
INSERT INTO cronjobs_history VALUES("10","4","Ejecuci&oacute;n autom&aacute;tica exitosa","1741721102");
INSERT INTO cronjobs_history VALUES("11","1","Ejecuci&oacute;n autom&aacute;tica exitosa","1741721282");
INSERT INTO cronjobs_history VALUES("12","1","Ejecuci&oacute;n autom&aacute;tica exitosa","1741723142");
INSERT INTO cronjobs_history VALUES("13","4","Ejecuci&oacute;n autom&aacute;tica exitosa","1741724762");
INSERT INTO cronjobs_history VALUES("14","1","Ejecuci&oacute;n autom&aacute;tica exitosa","1741725002");
INSERT INTO cronjobs_history VALUES("15","1","Ejecuci&oacute;n autom&aacute;tica exitosa","1741726861");
INSERT INTO cronjobs_history VALUES("16","4","Ejecuci&oacute;n autom&aacute;tica exitosa","1741728422");
INSERT INTO cronjobs_history VALUES("17","1","Ejecuci&oacute;n autom&aacute;tica exitosa","1741728721");
INSERT INTO cronjobs_history VALUES("18","1","Ejecuci&oacute;n autom&aacute;tica exitosa","1741730581");
INSERT INTO cronjobs_history VALUES("19","4","Ejecuci&oacute;n autom&aacute;tica exitosa","1741732081");
INSERT INTO cronjobs_history VALUES("20","1","Ejecuci&oacute;n autom&aacute;tica exitosa","1741732382");
INSERT INTO cronjobs_history VALUES("21","1","Ejecuci&oacute;n autom&aacute;tica exitosa","1741734242");
INSERT INTO cronjobs_history VALUES("22","4","Ejecuci&oacute;n autom&aacute;tica exitosa","1741735742");
INSERT INTO cronjobs_history VALUES("23","1","Ejecuci&oacute;n autom&aacute;tica exitosa","1741736101");
INSERT INTO cronjobs_history VALUES("24","1","Ejecuci&oacute;n autom&aacute;tica exitosa","1741737902");
INSERT INTO cronjobs_history VALUES("25","4","Ejecuci&oacute;n autom&aacute;tica exitosa","1741739402");
INSERT INTO cronjobs_history VALUES("26","1","Ejecuci&oacute;n autom&aacute;tica exitosa","1741739762");
INSERT INTO cronjobs_history VALUES("27","1","Ejecuci&oacute;n autom&aacute;tica exitosa","1741741621");
INSERT INTO cronjobs_history VALUES("28","4","Ejecuci&oacute;n autom&aacute;tica exitosa","1741743062");
INSERT INTO cronjobs_history VALUES("29","1","Ejecuci&oacute;n autom&aacute;tica exitosa","1741743481");
INSERT INTO cronjobs_history VALUES("30","1","Ejecuci&oacute;n autom&aacute;tica exitosa","1741745341");
INSERT INTO cronjobs_history VALUES("31","4","Ejecuci&oacute;n autom&aacute;tica exitosa","1741746722");
INSERT INTO cronjobs_history VALUES("32","1","Ejecuci&oacute;n autom&aacute;tica exitosa","1741747202");
INSERT INTO cronjobs_history VALUES("33","1","Ejecuci&oacute;n autom&aacute;tica exitosa","1741749061");
INSERT INTO cronjobs_history VALUES("34","4","Ejecuci&oacute;n autom&aacute;tica exitosa","1741750382");
INSERT INTO cronjobs_history VALUES("35","1","Ejecuci&oacute;n autom&aacute;tica exitosa","1741750862");
INSERT INTO cronjobs_history VALUES("36","1","Ejecuci&oacute;n autom&aacute;tica exitosa","1741752722");
INSERT INTO cronjobs_history VALUES("37","4","Ejecuci&oacute;n autom&aacute;tica exitosa","1741754041");
INSERT INTO cronjobs_history VALUES("38","1","Ejecuci&oacute;n autom&aacute;tica exitosa","1741754582");
INSERT INTO cronjobs_history VALUES("39","1","Ejecuci&oacute;n autom&aacute;tica exitosa","1741756441");
INSERT INTO cronjobs_history VALUES("40","4","Ejecuci&oacute;n autom&aacute;tica exitosa","1741757642");
INSERT INTO cronjobs_history VALUES("41","1","Ejecuci&oacute;n autom&aacute;tica exitosa","1741758242");
INSERT INTO cronjobs_history VALUES("42","1","Ejecuci&oacute;n autom&aacute;tica exitosa","1741760102");
INSERT INTO cronjobs_history VALUES("43","4","Ejecuci&oacute;n autom&aacute;tica exitosa","1741761302");
INSERT INTO cronjobs_history VALUES("44","1","Ejecuci&oacute;n autom&aacute;tica exitosa","1741761962");
INSERT INTO cronjobs_history VALUES("45","1","Ejecuci&oacute;n autom&aacute;tica exitosa","1741763822");
INSERT INTO cronjobs_history VALUES("46","4","Ejecuci&oacute;n autom&aacute;tica exitosa","1741764962");
INSERT INTO cronjobs_history VALUES("47","1","Ejecuci&oacute;n autom&aacute;tica exitosa","1741765682");
INSERT INTO cronjobs_history VALUES("48","1","Ejecuci&oacute;n autom&aacute;tica exitosa","1741767541");
INSERT INTO cronjobs_history VALUES("49","4","Ejecuci&oacute;n autom&aacute;tica exitosa","1741768622");
INSERT INTO cronjobs_history VALUES("50","1","Ejecuci&oacute;n autom&aacute;tica exitosa","1741769402");
INSERT INTO cronjobs_history VALUES("51","1","Ejecuci&oacute;n autom&aacute;tica exitosa","1741771262");
INSERT INTO cronjobs_history VALUES("52","4","Ejecuci&oacute;n autom&aacute;tica exitosa","1741772282");
INSERT INTO cronjobs_history VALUES("53","1","Ejecuci&oacute;n autom&aacute;tica exitosa","1741773122");
INSERT INTO cronjobs_history VALUES("54","1","Ejecuci&oacute;n autom&aacute;tica exitosa","1741774981");
INSERT INTO cronjobs_history VALUES("55","4","Ejecuci&oacute;n autom&aacute;tica exitosa","1741775942");
INSERT INTO cronjobs_history VALUES("56","1","Ejecuci&oacute;n autom&aacute;tica exitosa","1741776782");
INSERT INTO cronjobs_history VALUES("57","1","Ejecuci&oacute;n autom&aacute;tica exitosa","1741778642");
INSERT INTO cronjobs_history VALUES("58","4","Ejecuci&oacute;n autom&aacute;tica exitosa","1741779602");
INSERT INTO cronjobs_history VALUES("59","1","Ejecuci&oacute;n autom&aacute;tica exitosa","1741780501");
INSERT INTO cronjobs_history VALUES("60","1","Ejecuci&oacute;n autom&aacute;tica exitosa","1741782302");
INSERT INTO cronjobs_history VALUES("61","4","Ejecuci&oacute;n autom&aacute;tica exitosa","1741783262");
INSERT INTO cronjobs_history VALUES("62","1","Ejecuci&oacute;n autom&aacute;tica exitosa","1741784161");
INSERT INTO cronjobs_history VALUES("63","1","Ejecuci&oacute;n autom&aacute;tica exitosa","1741785962");
INSERT INTO cronjobs_history VALUES("64","4","Ejecuci&oacute;n autom&aacute;tica exitosa","1741786921");
INSERT INTO cronjobs_history VALUES("65","1","Ejecuci&oacute;n autom&aacute;tica exitosa","1741787822");
INSERT INTO cronjobs_history VALUES("66","1","Ejecuci&oacute;n autom&aacute;tica exitosa","1741789682");
INSERT INTO cronjobs_history VALUES("67","4","Ejecuci&oacute;n autom&aacute;tica exitosa","1741790522");
INSERT INTO cronjobs_history VALUES("68","1","Ejecuci&oacute;n autom&aacute;tica exitosa","1741791542");
INSERT INTO cronjobs_history VALUES("69","1","Ejecuci&oacute;n autom&aacute;tica exitosa","1741793402");
INSERT INTO cronjobs_history VALUES("70","4","Ejecuci&oacute;n autom&aacute;tica exitosa","1741794182");
INSERT INTO cronjobs_history VALUES("71","1","Ejecuci&oacute;n autom&aacute;tica exitosa","1741795261");
INSERT INTO cronjobs_history VALUES("72","1","Ejecuci&oacute;n autom&aacute;tica exitosa","1741797122");
INSERT INTO cronjobs_history VALUES("73","4","Ejecuci&oacute;n autom&aacute;tica exitosa","1741797841");
INSERT INTO cronjobs_history VALUES("74","1","Ejecuci&oacute;n autom&aacute;tica exitosa","1741798981");
INSERT INTO cronjobs_history VALUES("75","1","Ejecuci&oacute;n autom&aacute;tica exitosa","1741800782");
INSERT INTO cronjobs_history VALUES("76","4","Ejecuci&oacute;n autom&aacute;tica exitosa","1741801442");
INSERT INTO cronjobs_history VALUES("77","1","Ejecuci&oacute;n autom&aacute;tica exitosa","1741802642");
INSERT INTO cronjobs_history VALUES("78","1","Ejecuci&oacute;n autom&aacute;tica exitosa","1741804501");
INSERT INTO cronjobs_history VALUES("79","4","Ejecuci&oacute;n autom&aacute;tica exitosa","1741805102");
INSERT INTO cronjobs_history VALUES("80","1","Ejecuci&oacute;n autom&aacute;tica exitosa","1741806361");
INSERT INTO cronjobs_history VALUES("81","1","Ejecuci&oacute;n autom&aacute;tica exitosa","1741808162");
INSERT INTO cronjobs_history VALUES("82","4","Ejecuci&oacute;n autom&aacute;tica exitosa","1741808761");
INSERT INTO cronjobs_history VALUES("83","1","Ejecuci&oacute;n autom&aacute;tica exitosa","1741810021");
INSERT INTO cronjobs_history VALUES("84","1","Ejecuci&oacute;n autom&aacute;tica exitosa","1741811882");
INSERT INTO cronjobs_history VALUES("85","4","Ejecuci&oacute;n autom&aacute;tica exitosa","1741812362");
INSERT INTO cronjobs_history VALUES("86","1","Ejecuci&oacute;n autom&aacute;tica exitosa","1741813741");
INSERT INTO cronjobs_history VALUES("87","1","Ejecuci&oacute;n autom&aacute;tica exitosa","1741815542");
INSERT INTO cronjobs_history VALUES("88","4","Ejecuci&oacute;n autom&aacute;tica exitosa","1741816022");
INSERT INTO cronjobs_history VALUES("89","1","Ejecuci&oacute;n autom&aacute;tica exitosa","1741817401");
INSERT INTO cronjobs_history VALUES("90","1","Ejecuci&oacute;n autom&aacute;tica exitosa","1741819261");
INSERT INTO cronjobs_history VALUES("91","4","Ejecuci&oacute;n autom&aacute;tica exitosa","1741819681");
INSERT INTO cronjobs_history VALUES("92","1","Ejecuci&oacute;n autom&aacute;tica exitosa","1741821121");
INSERT INTO cronjobs_history VALUES("93","1","Ejecuci&oacute;n autom&aacute;tica exitosa","1741822922");
INSERT INTO cronjobs_history VALUES("94","4","Ejecuci&oacute;n autom&aacute;tica exitosa","1741823282");
INSERT INTO cronjobs_history VALUES("95","1","Ejecuci&oacute;n autom&aacute;tica exitosa","1741824782");
INSERT INTO cronjobs_history VALUES("96","1","Ejecuci&oacute;n autom&aacute;tica exitosa","1741826642");
INSERT INTO cronjobs_history VALUES("97","4","Ejecuci&oacute;n autom&aacute;tica exitosa","1741826941");
INSERT INTO cronjobs_history VALUES("98","1","Ejecuci&oacute;n autom&aacute;tica exitosa","1741828502");
INSERT INTO cronjobs_history VALUES("99","1","Ejecuci&oacute;n autom&aacute;tica exitosa","1741830362");
INSERT INTO cronjobs_history VALUES("100","4","Ejecuci&oacute;n autom&aacute;tica exitosa","1741830602");
INSERT INTO cronjobs_history VALUES("101","1","Ejecuci&oacute;n autom&aacute;tica exitosa","1741832221");
INSERT INTO cronjobs_history VALUES("102","1","Ejecuci&oacute;n autom&aacute;tica exitosa","1741834022");
INSERT INTO cronjobs_history VALUES("103","4","Ejecuci&oacute;n autom&aacute;tica exitosa","1741834262");
INSERT INTO cronjobs_history VALUES("104","1","Ejecuci&oacute;n autom&aacute;tica exitosa","1741835881");
INSERT INTO cronjobs_history VALUES("105","1","Ejecuci&oacute;n autom&aacute;tica exitosa","1741837742");
INSERT INTO cronjobs_history VALUES("106","4","Ejecuci&oacute;n autom&aacute;tica exitosa","1741837921");
INSERT INTO cronjobs_history VALUES("107","1","Ejecuci&oacute;n autom&aacute;tica exitosa","1741839602");
INSERT INTO cronjobs_history VALUES("108","1","Ejecuci&oacute;n autom&aacute;tica exitosa","1741841462");
INSERT INTO cronjobs_history VALUES("109","4","Ejecuci&oacute;n autom&aacute;tica exitosa","1741841581");
INSERT INTO cronjobs_history VALUES("110","1","Ejecuci&oacute;n autom&aacute;tica exitosa","1741843322");
INSERT INTO cronjobs_history VALUES("111","1","Ejecuci&oacute;n autom&aacute;tica exitosa","1741845181");
INSERT INTO cronjobs_history VALUES("112","4","Ejecuci&oacute;n autom&aacute;tica exitosa","1741845242");
INSERT INTO cronjobs_history VALUES("113","1","Ejecuci&oacute;n autom&aacute;tica exitosa","1741847042");
INSERT INTO cronjobs_history VALUES("114","1","Ejecuci&oacute;n autom&aacute;tica exitosa","1741848901");
INSERT INTO cronjobs_history VALUES("115","4","Ejecuci&oacute;n autom&aacute;tica exitosa","1741848901");
INSERT INTO cronjobs_history VALUES("116","1","Ejecuci&oacute;n autom&aacute;tica exitosa","1741850702");
INSERT INTO cronjobs_history VALUES("117","1","Ejecuci&oacute;n autom&aacute;tica exitosa","1741852562");
INSERT INTO cronjobs_history VALUES("118","4","Ejecuci&oacute;n autom&aacute;tica exitosa","1741852562");
INSERT INTO cronjobs_history VALUES("119","1","Ejecuci&oacute;n autom&aacute;tica exitosa","1741854422");
INSERT INTO cronjobs_history VALUES("120","4","Ejecuci&oacute;n autom&aacute;tica exitosa","1741856222");
INSERT INTO cronjobs_history VALUES("121","1","Ejecuci&oacute;n autom&aacute;tica exitosa","1741856282");
INSERT INTO cronjobs_history VALUES("122","1","Ejecuci&oacute;n autom&aacute;tica exitosa","1741858142");
INSERT INTO cronjobs_history VALUES("123","4","Ejecuci&oacute;n autom&aacute;tica exitosa","1741859882");
INSERT INTO cronjobs_history VALUES("124","1","Ejecuci&oacute;n autom&aacute;tica exitosa","1741860002");
INSERT INTO cronjobs_history VALUES("125","1","Ejecuci&oacute;n autom&aacute;tica exitosa","1741861861");
INSERT INTO cronjobs_history VALUES("126","4","Ejecuci&oacute;n autom&aacute;tica exitosa","1741863542");
INSERT INTO cronjobs_history VALUES("127","1","Ejecuci&oacute;n autom&aacute;tica exitosa","1741863722");
INSERT INTO cronjobs_history VALUES("128","1","Ejecuci&oacute;n autom&aacute;tica exitosa","1741865582");
INSERT INTO cronjobs_history VALUES("129","4","Ejecuci&oacute;n autom&aacute;tica exitosa","1741867202");
INSERT INTO cronjobs_history VALUES("130","1","Ejecuci&oacute;n autom&aacute;tica exitosa","1741867442");
INSERT INTO cronjobs_history VALUES("131","1","Ejecuci&oacute;n autom&aacute;tica exitosa","1741869301");
INSERT INTO cronjobs_history VALUES("132","4","Ejecuci&oacute;n autom&aacute;tica exitosa","1741870862");
INSERT INTO cronjobs_history VALUES("133","1","Ejecuci&oacute;n autom&aacute;tica exitosa","1741871102");
INSERT INTO cronjobs_history VALUES("134","1","Ejecuci&oacute;n autom&aacute;tica exitosa","1741872962");
INSERT INTO cronjobs_history VALUES("135","4","Ejecuci&oacute;n autom&aacute;tica exitosa","1741874521");
INSERT INTO cronjobs_history VALUES("136","1","Ejecuci&oacute;n autom&aacute;tica exitosa","1741874821");
INSERT INTO cronjobs_history VALUES("137","1","Ejecuci&oacute;n autom&aacute;tica exitosa","1741876682");
INSERT INTO cronjobs_history VALUES("138","4","Ejecuci&oacute;n autom&aacute;tica exitosa","1741878122");
INSERT INTO cronjobs_history VALUES("139","1","Ejecuci&oacute;n autom&aacute;tica exitosa","1741878542");
INSERT INTO cronjobs_history VALUES("140","1","Ejecuci&oacute;n autom&aacute;tica exitosa","1741880402");
INSERT INTO cronjobs_history VALUES("141","4","Ejecuci&oacute;n autom&aacute;tica exitosa","1741881781");
INSERT INTO cronjobs_history VALUES("142","1","Ejecuci&oacute;n autom&aacute;tica exitosa","1741882262");
INSERT INTO cronjobs_history VALUES("143","1","Ejecuci&oacute;n autom&aacute;tica exitosa","1741884122");
INSERT INTO cronjobs_history VALUES("144","4","Ejecuci&oacute;n autom&aacute;tica exitosa","1741885386");
INSERT INTO cronjobs_history VALUES("145","1","Ejecuci&oacute;n autom&aacute;tica exitosa","1741885982");
INSERT INTO cronjobs_history VALUES("146","1","Ejecuci&oacute;n autom&aacute;tica exitosa","1741887841");
INSERT INTO cronjobs_history VALUES("147","4","Ejecuci&oacute;n autom&aacute;tica exitosa","1741889044");
INSERT INTO cronjobs_history VALUES("148","1","Ejecuci&oacute;n autom&aacute;tica exitosa","1741889642");
INSERT INTO cronjobs_history VALUES("149","1","Ejecuci&oacute;n autom&aacute;tica exitosa","1741891501");
INSERT INTO cronjobs_history VALUES("150","4","Ejecuci&oacute;n autom&aacute;tica exitosa","1741892705");
INSERT INTO cronjobs_history VALUES("151","1","Ejecuci&oacute;n autom&aacute;tica exitosa","1741893361");
INSERT INTO cronjobs_history VALUES("152","1","Ejecuci&oacute;n autom&aacute;tica exitosa","1741895222");
INSERT INTO cronjobs_history VALUES("153","4","Ejecuci&oacute;n autom&aacute;tica exitosa","1741896364");
INSERT INTO cronjobs_history VALUES("154","1","Ejecuci&oacute;n autom&aacute;tica exitosa","1741897082");
INSERT INTO cronjobs_history VALUES("155","1","Ejecuci&oacute;n autom&aacute;tica exitosa","1741898941");
INSERT INTO cronjobs_history VALUES("156","4","Ejecuci&oacute;n autom&aacute;tica exitosa","1741900023");
INSERT INTO cronjobs_history VALUES("157","1","Ejecuci&oacute;n autom&aacute;tica exitosa","1741900742");
INSERT INTO cronjobs_history VALUES("158","1","Ejecuci&oacute;n autom&aacute;tica exitosa","1741902601");
INSERT INTO cronjobs_history VALUES("159","4","Ejecuci&oacute;n autom&aacute;tica exitosa","1741903694");
INSERT INTO cronjobs_history VALUES("160","1","Ejecuci&oacute;n autom&aacute;tica exitosa","1741904402");
INSERT INTO cronjobs_history VALUES("161","1","Ejecuci&oacute;n autom&aacute;tica exitosa","1741906741");
INSERT INTO cronjobs_history VALUES("162","4","Ejecuci&oacute;n autom&aacute;tica exitosa","1741907353");
INSERT INTO cronjobs_history VALUES("163","1","Ejecuci&oacute;n autom&aacute;tica exitosa","1741908602");
INSERT INTO cronjobs_history VALUES("164","1","Ejecuci&oacute;n autom&aacute;tica exitosa","1741910462");
INSERT INTO cronjobs_history VALUES("165","4","Ejecuci&oacute;n autom&aacute;tica exitosa","1741911014");
INSERT INTO cronjobs_history VALUES("166","1","Ejecuci&oacute;n autom&aacute;tica exitosa","1741912322");
INSERT INTO cronjobs_history VALUES("167","1","Ejecuci&oacute;n autom&aacute;tica exitosa","1741914181");
INSERT INTO cronjobs_history VALUES("168","4","Ejecuci&oacute;n autom&aacute;tica exitosa","1741914673");
INSERT INTO cronjobs_history VALUES("169","1","Ejecuci&oacute;n autom&aacute;tica exitosa","1741916041");
INSERT INTO cronjobs_history VALUES("170","1","Ejecuci&oacute;n autom&aacute;tica exitosa","1741917842");
INSERT INTO cronjobs_history VALUES("171","4","Ejecuci&oacute;n autom&aacute;tica exitosa","1741918323");
INSERT INTO cronjobs_history VALUES("172","1","Ejecuci&oacute;n autom&aacute;tica exitosa","1741919701");
INSERT INTO cronjobs_history VALUES("173","1","Ejecuci&oacute;n autom&aacute;tica exitosa","1741921502");
INSERT INTO cronjobs_history VALUES("174","4","Ejecuci&oacute;n autom&aacute;tica exitosa","1741922042");
INSERT INTO cronjobs_history VALUES("175","1","Ejecuci&oacute;n autom&aacute;tica exitosa","1741923361");
INSERT INTO cronjobs_history VALUES("176","1","Ejecuci&oacute;n autom&aacute;tica exitosa","1742060402");
INSERT INTO cronjobs_history VALUES("177","4","Ejecuci&oacute;n autom&aacute;tica exitosa","1742060413");
INSERT INTO cronjobs_history VALUES("178","1","Ejecuci&oacute;n autom&aacute;tica exitosa","1742062261");
INSERT INTO cronjobs_history VALUES("179","4","Ejecuci&oacute;n autom&aacute;tica exitosa","1742064063");
INSERT INTO cronjobs_history VALUES("180","1","Ejecuci&oacute;n autom&aacute;tica exitosa","1742064121");
INSERT INTO cronjobs_history VALUES("181","1","Ejecuci&oacute;n autom&aacute;tica exitosa","1742065981");
INSERT INTO cronjobs_history VALUES("182","4","Ejecuci&oacute;n autom&aacute;tica exitosa","1742067723");
INSERT INTO cronjobs_history VALUES("183","1","Ejecuci&oacute;n autom&aacute;tica exitosa","1742067782");
INSERT INTO cronjobs_history VALUES("184","1","Ejecuci&oacute;n autom&aacute;tica exitosa","1742069641");
INSERT INTO cronjobs_history VALUES("185","4","Ejecuci&oacute;n autom&aacute;tica exitosa","1742071384");
INSERT INTO cronjobs_history VALUES("186","1","Ejecuci&oacute;n autom&aacute;tica exitosa","1742071502");
INSERT INTO cronjobs_history VALUES("187","1","Ejecuci&oacute;n autom&aacute;tica exitosa","1742073361");
INSERT INTO cronjobs_history VALUES("188","4","Ejecuci&oacute;n autom&aacute;tica exitosa","1742075043");
INSERT INTO cronjobs_history VALUES("189","1","Ejecuci&oacute;n autom&aacute;tica exitosa","1742075162");
INSERT INTO cronjobs_history VALUES("190","4","Ejecuci&oacute;n autom&aacute;tica exitosa","1744119425");
INSERT INTO cronjobs_history VALUES("191","4","Prueba exitosa","1744119425");
INSERT INTO cronjobs_history VALUES("192","5","Prueba exitosa","1744119592");
INSERT INTO cronjobs_history VALUES("193","5","Error en la ejecuci&oacute;n (302)","1744119751");
INSERT INTO cronjobs_history VALUES("194","5","Prueba exitosa","1744119751");
INSERT INTO cronjobs_history VALUES("195","5","Error en la ejecuci&oacute;n (302)","1744119831");
INSERT INTO cronjobs_history VALUES("196","5","Prueba exitosa","1744119831");
INSERT INTO cronjobs_history VALUES("197","5","Error en la ejecución (302)","1744120503");
INSERT INTO cronjobs_history VALUES("198","5","Prueba exitosa","1744120503");
INSERT INTO cronjobs_history VALUES("199","5","Error en la ejecución (302)","1744120565");
INSERT INTO cronjobs_history VALUES("200","5","Error en la ejecución (302)","1744121521");
INSERT INTO cronjobs_history VALUES("201","5","Error en la ejecución (302)","1744145563");
INSERT INTO cronjobs_history VALUES("202","5","Error en la ejecución (302)","1744145571");
INSERT INTO cronjobs_history VALUES("203","5","Error en la ejecución (302)","1744145604");
INSERT INTO cronjobs_history VALUES("204","5","Error en la ejecución (302)","1744145629");
INSERT INTO cronjobs_history VALUES("205","5","Error en la ejecución (302)","1744145649");
INSERT INTO cronjobs_history VALUES("206","5","Error en la ejecución (302)","1744145749");
INSERT INTO cronjobs_history VALUES("207","5","Error en la ejecución (302)","1744145895");
INSERT INTO cronjobs_history VALUES("208","5","Error en la ejecución (302)","1744145941");
INSERT INTO cronjobs_history VALUES("209","5","Error en la ejecución (302)","1744145999");
INSERT INTO cronjobs_history VALUES("210","5","Error en la ejecución (302)","1744146027");
INSERT INTO cronjobs_history VALUES("211","5","Error en la ejecución (302)","1744146046");



DROP TABLE IF EXISTS currency;

CREATE TABLE `currency` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `currency_iso` varchar(3) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `language` varchar(3) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `currency_name` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `money` varchar(30) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `money_plural` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `symbol` varchar(3) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `registration_date` datetime NOT NULL,
  `state` bigint NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;

INSERT INTO currency VALUES("1","PEN","ES","SOLES","SOL","SOLES","$","2022-07-07 19:57:37","1");



DROP TABLE IF EXISTS departures;

CREATE TABLE `departures` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `billid` bigint NOT NULL,
  `productid` bigint NOT NULL,
  `departure_date` datetime NOT NULL,
  `description` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `quantity_departures` bigint NOT NULL,
  `unit_price` decimal(12,2) NOT NULL,
  `total_cost` decimal(12,2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `billid` (`billid`),
  KEY `productid` (`productid`),
  CONSTRAINT `departures_ibfk_1` FOREIGN KEY (`productid`) REFERENCES `products` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;




DROP TABLE IF EXISTS detail_bills;

CREATE TABLE `detail_bills` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `billid` bigint NOT NULL,
  `type` bigint NOT NULL,
  `serproid` bigint NOT NULL,
  `description` text CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `quantity` bigint NOT NULL,
  `price` decimal(12,2) NOT NULL,
  `total` decimal(12,2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `billid` (`billid`),
  CONSTRAINT `detail_bills_ibfk_1` FOREIGN KEY (`billid`) REFERENCES `bills` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=106 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;

INSERT INTO detail_bills VALUES("1","1","2","1","SERVICIO DE HOGAR, MES DE MARZO PRORRATEADO","1","31.00","31.00");
INSERT INTO detail_bills VALUES("2","2","2","1","SERVICIO DE HOGAR, MES DE ABRIL","1","50.00","50.00");
INSERT INTO detail_bills VALUES("3","3","1","","SERVICIO DE INSTALACIÓN","1","500.00","500.00");
INSERT INTO detail_bills VALUES("5","4","2","1","SERVICIO DE HOGAR, MES DE MARZO PRORRATEADO","1","27.00","27.00");
INSERT INTO detail_bills VALUES("6","5","2","1","SERVICIO DE HOGAR, MES DE ABRIL","1","50.00","50.00");
INSERT INTO detail_bills VALUES("7","6","2","1","SERVICIO DE HOGAR, MES DE MAYO","1","50.00","50.00");
INSERT INTO detail_bills VALUES("30","11","2","1","SERVICIO DE HOGAR, MES DE MARZO PRORRATEADO","1","33.30","33.30");
INSERT INTO detail_bills VALUES("41","17","2","1","SERVICIO DE HOGAR, MES DE ABRIL","1","50.00","50.00");
INSERT INTO detail_bills VALUES("42","18","2","1","SERVICIO DE HOGAR, MES DE MAYO","1","50.00","50.00");
INSERT INTO detail_bills VALUES("53","29","2","1","SERVICIO DE HOGAR, MES DE ABRIL PRORRATEADO","1","19.00","19.00");
INSERT INTO detail_bills VALUES("104","80","2","1","SERVICIO DE HOGAR, MES DE MAYO","1","50.00","50.00");
INSERT INTO detail_bills VALUES("105","81","2","1","SERVICIO DE HOGAR, MES DE MAYO","1","50.00","50.00");



DROP TABLE IF EXISTS detail_contracts;

CREATE TABLE `detail_contracts` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `contractid` bigint NOT NULL,
  `serviceid` bigint NOT NULL,
  `price` decimal(12,2) NOT NULL,
  `registration_date` datetime NOT NULL,
  `state` bigint NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `contractid` (`contractid`),
  KEY `serviceid` (`serviceid`),
  CONSTRAINT `detail_contracts_ibfk_1` FOREIGN KEY (`contractid`) REFERENCES `contracts` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `detail_contracts_ibfk_2` FOREIGN KEY (`serviceid`) REFERENCES `services` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;

INSERT INTO detail_contracts VALUES("1","1","1","50.00","2025-03-11 12:31:30","2");
INSERT INTO detail_contracts VALUES("2","2","1","50.00","2025-03-13 20:01:25","3");
INSERT INTO detail_contracts VALUES("3","3","1","50.00","2025-03-13 21:00:10","2");
INSERT INTO detail_contracts VALUES("4","4","1","50.00","2025-03-14 15:36:15","1");
INSERT INTO detail_contracts VALUES("5","5","1","50.00","2025-03-17 14:00:43","1");
INSERT INTO detail_contracts VALUES("6","6","1","50.00","2025-03-18 10:35:34","1");
INSERT INTO detail_contracts VALUES("7","7","2","40.00","2025-03-18 10:37:30","1");
INSERT INTO detail_contracts VALUES("8","8","2","40.00","2025-03-18 16:31:25","2");
INSERT INTO detail_contracts VALUES("9","9","1","50.00","2025-03-27 23:29:45","1");



DROP TABLE IF EXISTS detail_facility;

CREATE TABLE `detail_facility` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `facilityid` bigint NOT NULL,
  `technicalid` bigint NOT NULL,
  `opening_date` datetime NOT NULL,
  `closing_date` datetime NOT NULL,
  `comment` text CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `state` bigint NOT NULL,
  `red_type` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci DEFAULT NULL,
  `ip` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `facilityid` (`facilityid`),
  KEY `technicalid` (`technicalid`),
  CONSTRAINT `detail_facility_ibfk_1` FOREIGN KEY (`facilityid`) REFERENCES `facility` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `detail_facility_ibfk_2` FOREIGN KEY (`technicalid`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;

INSERT INTO detail_facility VALUES("1","1","1","2025-03-13 12:35:50","2025-03-13 15:02:31","SDSDSA","1","","");
INSERT INTO detail_facility VALUES("2","3","1","2025-03-13 21:19:16","2025-03-13 21:19:31","OK","1","","");
INSERT INTO detail_facility VALUES("3","2","1","2025-03-13 21:23:21","2025-03-13 21:25:19","SDSDS","1","","");



DROP TABLE IF EXISTS document_type;

CREATE TABLE `document_type` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `document` varchar(100) COLLATE utf8mb3_spanish2_ci NOT NULL,
  `maxlength` int NOT NULL DEFAULT '8',
  `is_required` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_spanish2_ci;

INSERT INTO document_type VALUES("1","SIN DOCUMENTO","8","");
INSERT INTO document_type VALUES("2","DNI","8","1");
INSERT INTO document_type VALUES("3","RUC","11","1");
INSERT INTO document_type VALUES("4","CARNET DE EXTRANJERIA","20","");
INSERT INTO document_type VALUES("5","PASAPORTE","20","");



DROP TABLE IF EXISTS emails;

CREATE TABLE `emails` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `clientid` bigint NOT NULL,
  `billid` bigint NOT NULL,
  `affair` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `sender` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `files` varchar(10) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `type_file` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `template_email` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `registration_date` datetime NOT NULL,
  `state` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `clientid` (`clientid`),
  KEY `billid` (`billid`),
  CONSTRAINT `emails_ibfk_1` FOREIGN KEY (`billid`) REFERENCES `bills` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `emails_ibfk_2` FOREIGN KEY (`clientid`) REFERENCES `clients` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;

INSERT INTO emails VALUES("1","4","4","FACTURA PENDIENTE DE PAGO","facturas@suportecnetwork.com","true","ticket","notification","2025-03-13 21:26:14","1");
INSERT INTO emails VALUES("5","4","4","FACTURA PENDIENTE DE PAGO","facturas@suportecnetwork.com","true","ticket","notification","2025-03-27 09:11:24","1");
INSERT INTO emails VALUES("9","9","29","FACTURA PENDIENTE DE PAGO","facturas@suportecnetwork.com","true","ticket","notification","2025-04-08 08:37:02","1");
INSERT INTO emails VALUES("10","4","5","FACTURA PENDIENTE DE PAGO","facturas@suportecnetwork.com","true","ticket","notification","2025-04-08 08:37:05","1");



DROP TABLE IF EXISTS facility;

CREATE TABLE `facility` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `clientid` bigint NOT NULL,
  `userid` bigint NOT NULL,
  `technical` bigint NOT NULL,
  `attention_date` datetime NOT NULL,
  `opening_date` datetime NOT NULL,
  `closing_date` datetime NOT NULL,
  `cost` decimal(12,2) NOT NULL,
  `detail` text CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `registration_date` datetime NOT NULL,
  `state` bigint NOT NULL DEFAULT '2',
  PRIMARY KEY (`id`),
  KEY `technicalid` (`userid`),
  KEY `clientid` (`clientid`),
  CONSTRAINT `facility_ibfk_2` FOREIGN KEY (`userid`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `facility_ibfk_3` FOREIGN KEY (`clientid`) REFERENCES `clients` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;

INSERT INTO facility VALUES("1","2","1","1","2025-03-11 00:22:00","2025-03-13 12:35:50","2025-03-13 15:02:31","0.00","","2025-03-11 12:31:30","1");
INSERT INTO facility VALUES("2","3","1","1","2025-03-13 19:59:00","2025-03-13 21:23:21","2025-03-13 21:25:19","0.00","","2025-03-13 20:01:25","1");
INSERT INTO facility VALUES("3","4","1","1","2025-03-13 21:57:00","2025-03-13 21:19:16","2025-03-13 21:19:31","500.00","ok","2025-03-13 21:00:10","1");
INSERT INTO facility VALUES("4","5","1","","2025-03-14 15:35:00","0000-00-00 00:00:00","0000-00-00 00:00:00","0.00","","2025-03-14 15:36:15","2");
INSERT INTO facility VALUES("5","6","1","","2025-03-17 12:59:00","0000-00-00 00:00:00","0000-00-00 00:00:00","0.00","","2025-03-17 14:00:43","2");
INSERT INTO facility VALUES("6","7","1","","2025-03-18 10:35:00","0000-00-00 00:00:00","0000-00-00 00:00:00","0.00","","2025-03-18 10:35:34","2");
INSERT INTO facility VALUES("7","8","1","","2025-03-18 10:36:00","0000-00-00 00:00:00","0000-00-00 00:00:00","0.00","","2025-03-18 10:37:30","2");
INSERT INTO facility VALUES("8","9","1","","2025-03-18 16:26:00","0000-00-00 00:00:00","0000-00-00 00:00:00","0.00","","2025-03-18 16:31:25","2");
INSERT INTO facility VALUES("9","10","1","","2025-03-27 23:23:00","0000-00-00 00:00:00","0000-00-00 00:00:00","0.00","","2025-03-27 23:29:45","2");



DROP TABLE IF EXISTS forms_payment;

CREATE TABLE `forms_payment` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `payment_type` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `registration_date` datetime NOT NULL,
  `state` bigint NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;

INSERT INTO forms_payment VALUES("1","EFECTIVO","2022-07-07 21:50:55","1");
INSERT INTO forms_payment VALUES("2","TRASNFERENCIA BANCARIA","2024-10-24 19:32:46","1");



DROP TABLE IF EXISTS gallery_images;

CREATE TABLE `gallery_images` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `clientid` bigint NOT NULL,
  `userid` bigint NOT NULL,
  `type` bigint NOT NULL,
  `typeid` bigint NOT NULL,
  `registration_date` datetime NOT NULL,
  `image` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `clientid` (`clientid`),
  KEY `userid` (`userid`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;

INSERT INTO gallery_images VALUES("1","2","1","1","1","2025-03-13 15:02:29","nada_ada_5025277906244a4e75b141539ed5cb6b.png");
INSERT INTO gallery_images VALUES("2","4","1","1","3","2025-03-13 21:19:29","juan_bertre_e6a38b60cabf8010c08cad19e5d66193.jpg");



DROP TABLE IF EXISTS incidents;

CREATE TABLE `incidents` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `incident` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `registration_date` datetime NOT NULL,
  `state` bigint NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;

INSERT INTO incidents VALUES("1","LUZ ROJA","2024-11-10 08:13:24","1");
INSERT INTO incidents VALUES("2","ANTENA DESALINEADA","2024-12-18 08:10:43","1");
INSERT INTO incidents VALUES("3","ROUTER WIFI RESETEADO(VALORES DE FABRICA)","2024-12-18 08:11:06","1");
INSERT INTO incidents VALUES("4","CAMBIO DE ROUTER WIFI","2024-12-18 08:11:24","1");
INSERT INTO incidents VALUES("5","INTERNET INTERMITENTE","2024-12-18 08:11:41","1");
INSERT INTO incidents VALUES("6","POE DAñADO","2024-12-18 08:11:57","1");
INSERT INTO incidents VALUES("7","CABLE FIBRA DAñADO","2024-12-18 08:12:10","1");
INSERT INTO incidents VALUES("8","CAMBIO A FIBRA ÓPTICA","2024-12-18 08:12:46","1");
INSERT INTO incidents VALUES("9","CANCELACIóN","2024-12-18 08:13:08","1");
INSERT INTO incidents VALUES("10","TEST","2025-03-13 23:17:49","1");



DROP TABLE IF EXISTS income;

CREATE TABLE `income` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `productid` bigint NOT NULL,
  `income_date` datetime NOT NULL,
  `description` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `quantity_income` bigint NOT NULL,
  `unit_price` decimal(12,2) NOT NULL,
  `total_cost` decimal(12,2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `productid` (`productid`),
  CONSTRAINT `income_ibfk_1` FOREIGN KEY (`productid`) REFERENCES `products` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;




DROP TABLE IF EXISTS messages_history;

CREATE TABLE `messages_history` (
  `id` int NOT NULL AUTO_INCREMENT,
  `templateid` int NOT NULL,
  `result` varchar(64) COLLATE utf8mb4_spanish2_ci NOT NULL,
  `date` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;




DROP TABLE IF EXISTS messages_history_clients;

CREATE TABLE `messages_history_clients` (
  `id` int NOT NULL AUTO_INCREMENT,
  `messageid` int NOT NULL,
  `clientid` int NOT NULL,
  `message` varchar(2048) COLLATE utf8mb4_spanish2_ci NOT NULL,
  `attachment` varchar(256) COLLATE utf8mb4_spanish2_ci NOT NULL,
  `attachment_type` int NOT NULL,
  `contact` int NOT NULL,
  `result` varchar(64) COLLATE utf8mb4_spanish2_ci NOT NULL,
  `date` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;




DROP TABLE IF EXISTS modules;

CREATE TABLE `modules` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `module` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `state` bigint NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;

INSERT INTO modules VALUES("1","Dashboard","1");
INSERT INTO modules VALUES("2","Clientes","1");
INSERT INTO modules VALUES("3","Usuarios","1");
INSERT INTO modules VALUES("4","Tickets","1");
INSERT INTO modules VALUES("5","Incidencias","1");
INSERT INTO modules VALUES("6","Facturas","1");
INSERT INTO modules VALUES("7","Productos","1");
INSERT INTO modules VALUES("8","Categorias","1");
INSERT INTO modules VALUES("9","Proveedores","1");
INSERT INTO modules VALUES("10","Pagos","1");
INSERT INTO modules VALUES("11","Servicios","1");
INSERT INTO modules VALUES("12","Empresa","1");
INSERT INTO modules VALUES("13","Instalaciones","1");
INSERT INTO modules VALUES("14","Divisas","1");
INSERT INTO modules VALUES("15","Formas de pago","1");
INSERT INTO modules VALUES("16","Comprobantes","1");
INSERT INTO modules VALUES("17","Unidades","1");
INSERT INTO modules VALUES("18","Correos","1");
INSERT INTO modules VALUES("19","Gestión de Red","1");
INSERT INTO modules VALUES("20","Campaña","1");



DROP TABLE IF EXISTS network_clients_usage;

CREATE TABLE `network_clients_usage` (
  `id` int NOT NULL AUTO_INCREMENT,
  `clientid` int NOT NULL,
  `diff` int NOT NULL,
  `currenttx` int NOT NULL,
  `currentrx` int NOT NULL,
  `date` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;




DROP TABLE IF EXISTS network_routers;

CREATE TABLE `network_routers` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `ip` varchar(256) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `port` int NOT NULL,
  `username` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `password` varchar(128) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `ip_range` varchar(128) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `zoneid` int NOT NULL,
  `identity` varchar(256) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `board_name` varchar(256) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `version` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `status` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;

INSERT INTO network_routers VALUES("2","ejemplo","146.190.61.104","80","sistemawispMK","RElawiH+1CQf4yOR3GFEBDZHb0RNRDNSNm5ZR3NnbkVlNTFOT1E9PQ==","192.168.18.1/24","2","","","","");
INSERT INTO network_routers VALUES("3","Router La Salvia -Gpon","45.230.216.49","18004","Suportecnetwork","QsATNJ3he5roX3TzD2B8Fi84QitFeE5lYVZpeE0zMHh0aUhlSUE9PQ==","10.66.3.1/24\n10.66.4.1/24","1","","","","");
INSERT INTO network_routers VALUES("4","oscar casa","146.190.61.104","8050","admin","nZ8vcUCu92IEQ/nxq3juOFRrNUNTQ0RIYmE3SlhjZjZhTWdKaEE9PQ==","172.16.10.2/24","2","","","","");
INSERT INTO network_routers VALUES("5","ejemplo ppoe","146.190.61.104","80","sistemawispMK","IcHv5lCDjhXM+HS3Etgof3FhK2VjMVRodDlyaTN2dzVQa1JCalE9PQ==","172.16.46.2/24","1","","","","");



DROP TABLE IF EXISTS network_zones;

CREATE TABLE `network_zones` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci NOT NULL,
  `mode` tinyint NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;

INSERT INTO network_zones VALUES("1","ppoe","2");
INSERT INTO network_zones VALUES("2","simple queue","1");



DROP TABLE IF EXISTS otros_ingresos;

CREATE TABLE `otros_ingresos` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tipo` enum('INGRESO','EGRESO') COLLATE utf8mb4_unicode_ci NOT NULL,
  `fecha` date DEFAULT NULL,
  `descripcion` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `monto` decimal(12,2) DEFAULT NULL,
  `userId` int DEFAULT NULL,
  `state` enum('NORMAL','PENDIENTE','PAGADO') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NORMAL',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO otros_ingresos VALUES("1","INGRESO","2025-03-13","ejemplo lorem","500.00","1","NORMAL");
INSERT INTO otros_ingresos VALUES("2","EGRESO","2025-03-14","dwdwd","23.00","1","PENDIENTE");
INSERT INTO otros_ingresos VALUES("3","INGRESO","2025-03-15","hola","200.00","1","NORMAL");



DROP TABLE IF EXISTS p_campos;

CREATE TABLE `p_campos` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `obligatorio` tinyint(1) DEFAULT NULL,
  `tablaId` int DEFAULT NULL,
  `tipo` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `campo` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;




DROP TABLE IF EXISTS p_tabla;

CREATE TABLE `p_tabla` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tabla` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;




DROP TABLE IF EXISTS payments;

CREATE TABLE `payments` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `billid` bigint NOT NULL,
  `userid` bigint NOT NULL,
  `clientid` bigint NOT NULL,
  `internal_code` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `paytypeid` bigint NOT NULL,
  `payment_date` datetime NOT NULL,
  `comment` text CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `amount_paid` decimal(12,2) NOT NULL,
  `amount_total` decimal(12,2) NOT NULL DEFAULT '0.00',
  `remaining_credit` decimal(12,2) NOT NULL DEFAULT '0.00',
  `state` bigint NOT NULL DEFAULT '1',
  `ticket_number` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci DEFAULT NULL,
  `reference_number` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `billid` (`billid`),
  KEY `clientid` (`clientid`),
  KEY `userid` (`userid`),
  KEY `paytypeid` (`paytypeid`)
) ENGINE=InnoDB AUTO_INCREMENT=146 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;

INSERT INTO payments VALUES("1","1","1","2","T00001","1","2025-03-13 15:13:00","","10.00","10.00","21.00","1","","");
INSERT INTO payments VALUES("2","1","1","2","T00002","1","2025-03-13 15:23:00","","21.00","31.00","0.00","1","","");
INSERT INTO payments VALUES("3","2","1","2","T00003","1","2025-03-13 15:23:00","","2.00","2.00","48.00","1","","");
INSERT INTO payments VALUES("4","3","1","4","T00004","1","2025-03-14 14:49:00","","20.00","20.00","480.00","1","","");
INSERT INTO payments VALUES("5","3","1","4","T00005","1","2025-03-14 15:41:00","","34.00","54.00","446.00","1","","");
INSERT INTO payments VALUES("6","3","1","4","T00006","1","2025-03-14 16:28:00","","2.00","56.00","444.00","1","","");
INSERT INTO payments VALUES("7","3","1","4","T00007","1","2025-03-14 17:35:00","","2.00","58.00","442.00","1","","");
INSERT INTO payments VALUES("8","3","1","4","T00008","1","2025-03-14 17:56:00","","23.00","81.00","419.00","1","","");
INSERT INTO payments VALUES("9","3","1","4","T00009","1","2025-03-14 17:58:00","","2.00","83.00","417.00","1","","");
INSERT INTO payments VALUES("10","3","1","4","T00010","1","2025-03-14 17:59:00","","23.00","106.00","394.00","1","","");
INSERT INTO payments VALUES("11","3","1","4","T00011","1","2025-03-14 17:59:00","","2.00","108.00","392.00","1","","");
INSERT INTO payments VALUES("12","3","1","4","T00012","1","2025-03-14 18:02:00","","2.00","110.00","390.00","1","","");
INSERT INTO payments VALUES("13","3","1","4","T00013","1","2025-03-14 18:13:00","","2.00","112.00","388.00","1","","");
INSERT INTO payments VALUES("14","3","1","4","T00014","1","2025-03-14 19:18:00","","23.00","135.00","365.00","1","","");
INSERT INTO payments VALUES("15","7","1","9","T00015","1","2025-03-25 19:46:00","","19.00","19.00","0.00","2","","");
INSERT INTO payments VALUES("16","7","1","9","T00016","1","2025-03-26 11:05:00","","10.00","10.00","0.00","2","","");
INSERT INTO payments VALUES("17","8","1","9","T00017","1","2025-03-26 11:05:00","","30.00","30.00","10.00","2","","");
INSERT INTO payments VALUES("26","7","1","9","T00018","1","2025-03-26 15:19:00","","5.00","9.00","0.00","2","","");
INSERT INTO payments VALUES("27","7","1","9","T00019","1","2025-03-26 15:19:00","","5.00","9.00","0.00","2","","");
INSERT INTO payments VALUES("28","7","1","9","T00020","1","2025-03-26 15:20:00","","5.00","5.00","0.00","2","","");
INSERT INTO payments VALUES("29","8","1","9","T00021","1","2025-03-26 15:20:00","","40.00","40.00","0.00","2","","");
INSERT INTO payments VALUES("30","7","1","9","T00022","1","2025-03-26 15:46:00","","5.00","9.00","0.00","2","","");
INSERT INTO payments VALUES("31","7","1","9","T00023","1","2025-03-26 15:47:00","","9.00","9.00","0.00","2","","");
INSERT INTO payments VALUES("32","8","1","9","T00024","1","2025-03-26 15:47:00","","20.00","20.00","0.00","2","","");
INSERT INTO payments VALUES("38","7","1","9","T00025","1","2025-03-26 16:55:00","","8.00","9.00","0.00","2","","");
INSERT INTO payments VALUES("40","7","1","9","T00026","1","2025-03-26 16:59:00","","9.00","9.00","0.00","2","","");
INSERT INTO payments VALUES("41","7","1","9","T00027","1","2025-03-27 05:59:00","","5.00","9.00","0.00","2","","");
INSERT INTO payments VALUES("42","7","1","9","T00028","1","2025-03-27 06:01:00","","5.00","5.00","0.00","2","","");
INSERT INTO payments VALUES("43","8","1","9","T00029","1","2025-03-27 06:01:00","","6.00","6.00","0.00","2","","");
INSERT INTO payments VALUES("44","7","1","9","T00030","1","2025-03-27 06:03:00","","1.00","11.00","18.00","2","","");
INSERT INTO payments VALUES("45","7","1","9","T00031","1","2025-03-27 06:05:00","","2.00","12.00","16.00","2","","");
INSERT INTO payments VALUES("46","7","1","9","T00032","1","2025-03-27 06:07:00","","3.00","15.00","0.00","2","","");
INSERT INTO payments VALUES("47","7","1","9","T00033","1","2025-03-27 06:07:00","","14.00","15.00","0.00","2","","");
INSERT INTO payments VALUES("48","8","1","9","T00034","1","2025-03-27 06:07:00","","10.00","36.00","40.00","2","","");
INSERT INTO payments VALUES("49","7","1","9","T00035","1","2025-03-27 06:09:00","","19.00","19.00","0.00","2","","");
INSERT INTO payments VALUES("50","8","1","9","T00036","1","2025-03-27 06:09:00","","1.00","50.00","0.00","2","","");
INSERT INTO payments VALUES("51","8","1","9","T00037","1","2025-03-27 06:10:00","","11.00","41.00","28.00","2","","");
INSERT INTO payments VALUES("52","8","1","9","T00038","1","2025-03-27 06:11:00","","19.00","50.00","0.00","2","","");
INSERT INTO payments VALUES("53","8","1","9","T00039","1","2025-03-27 06:11:00","","39.00","50.00","0.00","2","","");
INSERT INTO payments VALUES("54","7","1","9","T00040","1","2025-03-27 07:25:00","","19.00","19.00","0.00","2","","");
INSERT INTO payments VALUES("55","8","1","9","T00041","1","2025-03-27 07:34:00","","10.00","50.00","0.00","1","","");
INSERT INTO payments VALUES("56","7","1","9","T00042","1","2025-03-27 07:38:00","","9.00","19.00","0.00","2","","");
INSERT INTO payments VALUES("57","7","1","9","T00043","1","2025-03-27 07:41:00","","10.00","19.00","0.00","2","","");
INSERT INTO payments VALUES("58","7","1","9","T00044","1","2025-03-27 07:41:00","","11.00","19.00","0.00","2","","");
INSERT INTO payments VALUES("59","7","1","9","T00045","1","2025-03-27 07:42:00","","12.00","19.00","0.00","2","","");
INSERT INTO payments VALUES("60","7","1","9","T00046","1","2025-03-27 07:43:00","","13.00","19.00","0.00","2","","");
INSERT INTO payments VALUES("61","7","1","9","T00047","1","2025-03-27 07:43:00","","14.00","19.00","0.00","2","","");
INSERT INTO payments VALUES("62","7","1","9","T00048","1","2025-03-27 07:45:00","","15.00","19.00","0.00","2","","");
INSERT INTO payments VALUES("63","7","1","9","T00049","1","2025-03-27 07:46:00","","16.00","19.00","0.00","2","","");
INSERT INTO payments VALUES("64","7","1","9","T00050","1","2025-03-27 07:47:00","","17.00","19.00","0.00","2","","");
INSERT INTO payments VALUES("65","7","1","9","T00051","1","2025-03-27 07:49:00","","18.00","19.00","0.00","2","","");
INSERT INTO payments VALUES("66","7","1","9","T00052","1","2025-03-27 07:51:00","","19.00","19.00","0.00","2","","");
INSERT INTO payments VALUES("67","8","1","9","T00053","1","2025-03-27 07:52:00","","11.00","50.00","0.00","1","","");
INSERT INTO payments VALUES("68","8","1","9","T00054","1","2025-03-27 07:53:00","","12.00","50.00","0.00","1","","");
INSERT INTO payments VALUES("69","8","1","9","T00055","1","2025-03-27 08:03:00","","1.00","13.00","37.00","1","","");
INSERT INTO payments VALUES("70","7","1","9","T00056","1","2025-03-27 08:18:00","","1.00","19.00","0.00","1","","");
INSERT INTO payments VALUES("71","7","1","9","T00057","1","2025-03-27 08:19:00","A","2.00","19.00","0.00","1","","");
INSERT INTO payments VALUES("72","7","1","9","T00058","1","2025-03-27 08:20:00","OKOKOK","3.00","19.00","0.00","1","","");
INSERT INTO payments VALUES("73","7","1","9","T00059","1","2025-03-27 08:25:00","","5.00","19.00","0.00","1","","");
INSERT INTO payments VALUES("74","8","1","9","T00060","1","2025-03-27 09:03:00","","14.00","50.00","0.00","1","","");
INSERT INTO payments VALUES("75","7","1","9","T00061","1","2025-03-29 10:54:00","","11.00","19.00","0.00","1","","");
INSERT INTO payments VALUES("76","7","1","9","T00062","1","2025-03-29 10:55:00","","19.00","19.00","0.00","1","","");
INSERT INTO payments VALUES("77","8","1","9","T00063","1","2025-03-29 10:55:00","","50.00","50.00","0.00","1","","");
INSERT INTO payments VALUES("78","12","1","9","T00064","1","2025-03-29 10:58:00","","10.00","50.00","0.00","2","","");
INSERT INTO payments VALUES("80","12","1","9","T00065","1","2025-03-29 11:00:00","","10.00","50.00","0.00","2","","");
INSERT INTO payments VALUES("83","12","1","9","T00066","1","2025-03-29 11:09:00","","30.00","50.00","0.00","2","","");
INSERT INTO payments VALUES("84","13","1","9","T00067","1","2025-03-29 11:09:00","","20.00","50.00","30.00","2","","");
INSERT INTO payments VALUES("85","12","1","9","T00068","1","2025-03-29 11:54:00","","40.00","40.00","0.00","2","","");
INSERT INTO payments VALUES("86","13","1","9","T00069","1","2025-03-29 11:54:00","","10.00","50.00","0.00","2","","");
INSERT INTO payments VALUES("87","13","1","9","T00070","1","2025-03-29 11:55:00","","20.00","50.00","0.00","2","","");
INSERT INTO payments VALUES("88","12","1","9","T00071","1","2025-03-29 11:57:00","","40.00","40.00","0.00","1","","");
INSERT INTO payments VALUES("89","13","1","9","T00072","1","2025-03-29 11:57:00","","10.00","50.00","0.00","1","","");
INSERT INTO payments VALUES("90","13","1","9","T00073","1","2025-03-29 12:38:00","","40.00","50.00","0.00","1","","");
INSERT INTO payments VALUES("91","14","1","9","T00074","","2025-03-29 12:41:00","","50.00","50.00","0.00","1","","");
INSERT INTO payments VALUES("92","15","1","9","T00075","","2025-03-29 12:43:00","","50.00","50.00","0.00","1","","");
INSERT INTO payments VALUES("93","16","1","9","T00076","1","2025-03-29 12:44:00","","50.00","50.00","0.00","1","","");
INSERT INTO payments VALUES("94","3","1","4","T00077","1","2025-03-30 21:15:00","","100.00","500.00","0.00","1","","");
INSERT INTO payments VALUES("95","3","1","4","T00078","1","2025-03-30 21:21:00","","265.00","500.00","0.00","1","","");
INSERT INTO payments VALUES("96","11","1","3","T00079","1","2025-04-02 09:39:00","","10.00","33.30","0.00","1","","");
INSERT INTO payments VALUES("97","11","1","3","T00080","1","2025-04-02 11:15:00","","1.00","33.30","0.00","1","","");
INSERT INTO payments VALUES("98","11","1","3","T00081","1","2025-04-02 11:17:00","","1.00","33.30","0.00","1","","");
INSERT INTO payments VALUES("99","11","1","3","T00082","1","2025-04-02 15:51:00","","1.00","33.30","0.00","1","","");
INSERT INTO payments VALUES("100","11","1","3","T00083","1","2025-04-02 15:52:00","","1.00","33.30","0.00","1","","");
INSERT INTO payments VALUES("101","11","1","3","T00084","1","2025-04-02 16:35:00","","1.00","33.30","0.00","1","","");
INSERT INTO payments VALUES("102","11","1","3","T00085","1","2025-04-02 16:35:00","","1.00","33.30","0.00","1","","");
INSERT INTO payments VALUES("103","11","1","3","T00086","1","2025-04-02 16:41:00","","1.00","33.30","0.00","1","","");
INSERT INTO payments VALUES("104","11","1","3","T00087","1","2025-04-02 16:42:00","","0.30","33.30","0.00","1","","");
INSERT INTO payments VALUES("105","11","1","3","T00088","1","2025-04-02 16:42:00","","1.00","33.30","0.00","1","","");
INSERT INTO payments VALUES("106","11","1","3","T00089","1","2025-04-02 16:49:00","","1.00","33.30","0.00","1","","");
INSERT INTO payments VALUES("107","11","1","3","T00090","1","2025-04-02 16:56:00","","1.00","33.30","0.00","1","","");
INSERT INTO payments VALUES("108","11","1","3","T00091","1","2025-04-02 17:01:00","ASDFASF","1.00","33.30","0.00","1","","");
INSERT INTO payments VALUES("109","11","1","3","T00092","1","2025-04-02 17:02:00","","1.00","33.30","0.00","1","","");
INSERT INTO payments VALUES("110","6","1","4","T00093","1","2025-04-02 17:07:00","","1.00","50.00","0.00","1","","");
INSERT INTO payments VALUES("111","6","1","4","T00094","1","2025-04-02 17:12:00","","1.00","50.00","0.00","1","","");
INSERT INTO payments VALUES("112","11","1","3","T00095","1","2025-04-02 17:31:00","","1.00","33.30","0.00","1","","");
INSERT INTO payments VALUES("113","11","1","3","T00096","1","2025-04-02 17:36:00","DASFS","1.00","33.30","0.00","1","","");
INSERT INTO payments VALUES("114","11","1","3","T00097","1","2025-04-02 17:36:00","DASFS","1.00","33.30","0.00","1","","");
INSERT INTO payments VALUES("115","11","1","3","T00098","1","2025-04-02 17:36:00","DASFS","1.00","33.30","0.00","1","","");
INSERT INTO payments VALUES("116","11","1","3","T00099","1","2025-04-02 17:36:00","DASFS","1.00","33.30","0.00","1","","");
INSERT INTO payments VALUES("117","6","1","4","T00100","1","2025-04-02 17:42:00","SDAF","1.00","50.00","0.00","1","","");
INSERT INTO payments VALUES("118","6","1","4","T00101","1","2025-04-02 17:44:00","","1.00","50.00","0.00","1","","");
INSERT INTO payments VALUES("119","6","1","4","T00102","1","2025-04-02 17:45:00","","1.00","50.00","0.00","1","","");
INSERT INTO payments VALUES("120","6","1","4","T00103","1","2025-04-02 18:29:00","","1.00","50.00","0.00","1","","");
INSERT INTO payments VALUES("121","6","1","4","T00104","1","2025-04-02 18:29:00","ASDF","44.00","50.00","0.00","1","","");
INSERT INTO payments VALUES("122","5","1","4","T00105","1","2025-04-02 18:32:00","","1.00","50.00","0.00","1","","");
INSERT INTO payments VALUES("123","11","1","3","T00106","1","2025-04-02 18:33:00","ADFASF","6.00","33.30","0.00","1","","");
INSERT INTO payments VALUES("124","17","1","3","T00107","1","2025-04-02 18:34:00","ASDF","1.00","50.00","0.00","1","","");
INSERT INTO payments VALUES("125","17","1","3","T00108","1","2025-04-04 15:45:00","","1.00","50.00","0.00","1","","");
INSERT INTO payments VALUES("126","17","1","3","T00109","1","2025-04-04 15:45:00","","1.00","50.00","0.00","1","","");
INSERT INTO payments VALUES("127","17","1","3","T00110","1","2025-04-04 15:46:00","","1.00","50.00","0.00","1","","");
INSERT INTO payments VALUES("128","17","1","3","T00111","1","2025-04-05 08:21:00","","46.00","50.00","0.00","1","","");
INSERT INTO payments VALUES("129","18","1","3","T00112","1","2025-04-05 08:21:00","","50.00","50.00","0.00","1","","");
INSERT INTO payments VALUES("130","19","1","9","T00113","1","2025-04-05 08:22:00","","50.00","50.00","0.00","1","","");
INSERT INTO payments VALUES("131","20","1","9","T00114","1","2025-04-05 08:22:00","","50.00","50.00","0.00","1","","");
INSERT INTO payments VALUES("134","29","1","9","T00115","1","2025-04-08 07:52:00","","10.00","19.00","0.00","1","","");
INSERT INTO payments VALUES("135","29","1","9","T00116","1","2025-04-08 07:55:00","","1.00","19.00","0.00","1","","");
INSERT INTO payments VALUES("136","29","1","9","T00117","1","2025-04-08 07:58:00","","1.00","19.00","0.00","1","","");
INSERT INTO payments VALUES("137","29","1","9","T00118","1","2025-04-08 07:58:00","","1.00","19.00","0.00","1","","");
INSERT INTO payments VALUES("138","29","1","9","T00119","1","2025-04-08 07:58:00","","1.00","19.00","0.00","1","","");
INSERT INTO payments VALUES("139","29","1","9","T00120","1","2025-04-08 07:58:00","","1.00","19.00","0.00","1","","");
INSERT INTO payments VALUES("140","29","1","9","T00121","1","2025-04-08 07:58:00","","1.00","19.00","0.00","1","","");
INSERT INTO payments VALUES("141","29","1","9","T00122","1","2025-04-08 07:58:00","","1.00","19.00","0.00","1","","");
INSERT INTO payments VALUES("143","81","1","9","T00123","1","2025-04-08 14:10:00","ASDF","50.00","50.00","0.00","1","","");
INSERT INTO payments VALUES("145","29","1","9","T00124","1","2025-04-08 14:29:00","","2.00","19.00","0.00","1","","");



DROP TABLE IF EXISTS permits;

CREATE TABLE `permits` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `profileid` bigint NOT NULL,
  `moduleid` bigint NOT NULL,
  `r` bigint NOT NULL,
  `a` bigint NOT NULL,
  `e` bigint NOT NULL,
  `v` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `profileid` (`profileid`),
  KEY `moduleid` (`moduleid`)
) ENGINE=InnoDB AUTO_INCREMENT=256 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;

INSERT INTO permits VALUES("19","2","1","","","","1");
INSERT INTO permits VALUES("20","2","2","1","","","1");
INSERT INTO permits VALUES("21","2","3","","","","");
INSERT INTO permits VALUES("22","2","4","1","1","","1");
INSERT INTO permits VALUES("23","2","5","","","","");
INSERT INTO permits VALUES("24","2","6","","","","");
INSERT INTO permits VALUES("25","2","7","","","","");
INSERT INTO permits VALUES("26","2","8","","","","");
INSERT INTO permits VALUES("27","2","9","","","","");
INSERT INTO permits VALUES("28","2","10","1","","","1");
INSERT INTO permits VALUES("29","2","11","","","","");
INSERT INTO permits VALUES("30","2","12","","","","");
INSERT INTO permits VALUES("31","2","13","1","1","","1");
INSERT INTO permits VALUES("32","2","14","","","","");
INSERT INTO permits VALUES("33","2","15","","","","");
INSERT INTO permits VALUES("34","2","16","","","","");
INSERT INTO permits VALUES("35","2","17","","","","");
INSERT INTO permits VALUES("36","2","18","","","","");
INSERT INTO permits VALUES("199","3","1","1","","1","1");
INSERT INTO permits VALUES("200","3","2","1","1","","1");
INSERT INTO permits VALUES("201","3","3","1","","","1");
INSERT INTO permits VALUES("202","3","4","1","1","","1");
INSERT INTO permits VALUES("203","3","5","1","","","1");
INSERT INTO permits VALUES("204","3","6","1","","","1");
INSERT INTO permits VALUES("205","3","7","1","","","1");
INSERT INTO permits VALUES("206","3","8","1","","","1");
INSERT INTO permits VALUES("207","3","9","1","","","1");
INSERT INTO permits VALUES("208","3","10","1","","","1");
INSERT INTO permits VALUES("209","3","11","1","","","1");
INSERT INTO permits VALUES("210","3","12","1","","","1");
INSERT INTO permits VALUES("211","3","13","1","1","1","1");
INSERT INTO permits VALUES("212","3","14","1","","","1");
INSERT INTO permits VALUES("213","3","15","1","","","1");
INSERT INTO permits VALUES("214","3","16","1","","","1");
INSERT INTO permits VALUES("215","3","17","1","","","1");
INSERT INTO permits VALUES("216","3","18","1","","","1");
INSERT INTO permits VALUES("236","1","1","1","1","1","1");
INSERT INTO permits VALUES("237","1","2","1","1","1","1");
INSERT INTO permits VALUES("238","1","3","1","1","1","1");
INSERT INTO permits VALUES("239","1","4","1","1","1","1");
INSERT INTO permits VALUES("240","1","5","1","1","1","1");
INSERT INTO permits VALUES("241","1","6","1","1","1","1");
INSERT INTO permits VALUES("242","1","7","1","1","1","1");
INSERT INTO permits VALUES("243","1","8","1","1","1","1");
INSERT INTO permits VALUES("244","1","9","1","1","1","1");
INSERT INTO permits VALUES("245","1","10","1","1","1","1");
INSERT INTO permits VALUES("246","1","11","1","1","1","1");
INSERT INTO permits VALUES("247","1","12","1","1","1","1");
INSERT INTO permits VALUES("248","1","13","1","1","1","1");
INSERT INTO permits VALUES("249","1","14","1","1","1","1");
INSERT INTO permits VALUES("250","1","15","1","1","1","1");
INSERT INTO permits VALUES("251","1","16","1","1","1","1");
INSERT INTO permits VALUES("252","1","17","1","1","1","1");
INSERT INTO permits VALUES("253","1","18","1","1","1","1");
INSERT INTO permits VALUES("254","1","19","1","1","1","1");
INSERT INTO permits VALUES("255","1","20","1","1","1","1");



DROP TABLE IF EXISTS product_category;

CREATE TABLE `product_category` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `category` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `description` text CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `registration_date` datetime NOT NULL,
  `state` bigint NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;




DROP TABLE IF EXISTS products;

CREATE TABLE `products` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `internal_code` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `barcode` varchar(13) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `product` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `model` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `brand` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `extra_info` bigint NOT NULL,
  `serial_number` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `mac` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `description` text CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `sale_price` decimal(12,2) NOT NULL,
  `purchase_price` decimal(12,2) NOT NULL,
  `stock` bigint NOT NULL,
  `stock_alert` bigint NOT NULL,
  `categoryid` bigint NOT NULL,
  `unitid` bigint NOT NULL,
  `providerid` bigint NOT NULL,
  `image` text CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `registration_date` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `categoryid` (`categoryid`),
  KEY `unitid` (`unitid`),
  KEY `providerid` (`providerid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;




DROP TABLE IF EXISTS profiles;

CREATE TABLE `profiles` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `profile` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `description` varchar(300) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `registration_date` datetime NOT NULL,
  `state` bigint NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;

INSERT INTO profiles VALUES("1","ADMINISTRADOR","ACCESOS A TODOS LOS MODULOS","2022-07-07 15:51:53","1");
INSERT INTO profiles VALUES("2","TECNICO","CLIENTES, TICKET Y COBRANZA, CON RESTRICCIONES","2022-07-07 15:51:53","1");
INSERT INTO profiles VALUES("3","COBRANZA","COBRANZA DE FACTURAS PENDIENTES","2022-07-07 15:51:53","1");



DROP TABLE IF EXISTS providers;

CREATE TABLE `providers` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `provider` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `documentid` bigint NOT NULL,
  `document` varchar(15) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `mobile` varchar(10) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `email` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `address` text CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `registration_date` datetime NOT NULL,
  `state` bigint NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `documentid` (`documentid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;




DROP TABLE IF EXISTS services;

CREATE TABLE `services` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `internal_code` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `service` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `type` bigint NOT NULL,
  `rise` bigint NOT NULL,
  `rise_type` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `descent` bigint NOT NULL,
  `descent_type` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `price` decimal(12,2) NOT NULL,
  `details` text CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `routers` varchar(128) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `registration_date` datetime NOT NULL,
  `state` bigint NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;

INSERT INTO services VALUES("1","S00001","HOGAR","1","20","MBPS","25","MBPS","50.00","","","2025-03-11 12:31:20","1");
INSERT INTO services VALUES("2","S00002","OTRO PLAN","1","5","MBPS","6","MBPS","40.00","","","2025-03-18 10:39:47","1");



DROP TABLE IF EXISTS templates;

CREATE TABLE `templates` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `message` varchar(2048) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;




DROP TABLE IF EXISTS ticket_solution;

CREATE TABLE `ticket_solution` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `ticketid` bigint NOT NULL,
  `technicalid` bigint NOT NULL,
  `opening_date` datetime NOT NULL,
  `closing_date` datetime NOT NULL,
  `comment` text CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `state` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ticketid` (`ticketid`),
  KEY `technicalid` (`technicalid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;

INSERT INTO ticket_solution VALUES("1","4","1","2025-04-02 15:23:13","2025-04-02 15:23:26","RESUELTO","1");



DROP TABLE IF EXISTS tickets;

CREATE TABLE `tickets` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `userid` bigint NOT NULL,
  `clientid` bigint NOT NULL,
  `technical` bigint NOT NULL,
  `incidentsid` bigint NOT NULL,
  `description` text CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `priority` bigint NOT NULL,
  `attention_date` datetime NOT NULL,
  `opening_date` datetime NOT NULL,
  `closing_date` datetime NOT NULL,
  `registration_date` datetime NOT NULL,
  `state` bigint NOT NULL DEFAULT '2',
  PRIMARY KEY (`id`),
  KEY `userid` (`userid`),
  KEY `clientid` (`clientid`),
  KEY `incidentsid` (`incidentsid`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;

INSERT INTO tickets VALUES("1","1","4","","2","NAD QUE VER","1","2025-03-14 14:32:00","0000-00-00 00:00:00","0000-00-00 00:00:00","2025-03-14 14:33:08","5");
INSERT INTO tickets VALUES("2","1","4","","3","","1","2025-03-14 14:34:00","0000-00-00 00:00:00","0000-00-00 00:00:00","2025-03-14 14:34:51","5");
INSERT INTO tickets VALUES("3","1","9","","1","ok","1","2025-03-25 20:23:00","0000-00-00 00:00:00","0000-00-00 00:00:00","2025-03-25 20:24:17","5");
INSERT INTO tickets VALUES("4","1","9","1","1","prueba","1","2025-04-02 15:20:00","2025-04-02 15:23:13","2025-04-02 15:23:26","2025-04-02 15:20:26","1");
INSERT INTO tickets VALUES("5","1","2","","1","DFASDFDSDASFAFD","1","2025-04-02 15:23:00","0000-00-00 00:00:00","0000-00-00 00:00:00","2025-04-02 15:23:50","5");
INSERT INTO tickets VALUES("6","1","5","","2","ADFASFFDASFS","1","2025-04-02 15:24:00","0000-00-00 00:00:00","0000-00-00 00:00:00","2025-04-02 15:24:11","5");
INSERT INTO tickets VALUES("7","1","9","","2","ASDFASFFADSASDFADAFDS","1","2025-04-02 15:43:00","0000-00-00 00:00:00","0000-00-00 00:00:00","2025-04-02 15:44:04","5");
INSERT INTO tickets VALUES("8","1","9","","2","ASDFASFFADSASDFADAFDS","1","2025-04-11 15:43:00","0000-00-00 00:00:00","0000-00-00 00:00:00","2025-04-02 15:44:28","2");
INSERT INTO tickets VALUES("9","1","9","","2","ADSFASFSF","1","2025-04-24 15:45:00","0000-00-00 00:00:00","0000-00-00 00:00:00","2025-04-02 15:45:38","2");
INSERT INTO tickets VALUES("10","1","2","","2","ADFFSA","1","2025-04-02 15:48:00","0000-00-00 00:00:00","0000-00-00 00:00:00","2025-04-02 15:48:21","5");
INSERT INTO tickets VALUES("11","1","9","","2","SADFDASF","1","2025-04-03 15:49:00","0000-00-00 00:00:00","0000-00-00 00:00:00","2025-04-02 15:49:53","5");
INSERT INTO tickets VALUES("12","1","2","","1","ASDFASF","1","2025-04-03 11:11:00","0000-00-00 00:00:00","0000-00-00 00:00:00","2025-04-03 11:11:07","2");
INSERT INTO tickets VALUES("13","1","2","","1","SDFGDSF","1","2025-04-03 11:13:00","0000-00-00 00:00:00","0000-00-00 00:00:00","2025-04-03 11:13:25","2");
INSERT INTO tickets VALUES("14","1","3","","2","ASDFDASFD","1","2025-04-03 11:14:00","0000-00-00 00:00:00","0000-00-00 00:00:00","2025-04-03 11:14:04","5");
INSERT INTO tickets VALUES("15","1","2","","1","ADFAF","1","2025-04-03 11:15:00","0000-00-00 00:00:00","0000-00-00 00:00:00","2025-04-03 11:15:24","2");
INSERT INTO tickets VALUES("16","1","9","","1","asdfasf","1","2025-04-05 09:20:00","0000-00-00 00:00:00","0000-00-00 00:00:00","2025-04-05 09:21:01","5");
INSERT INTO tickets VALUES("17","1","9","","1","asdfasf","1","2025-04-05 10:09:00","0000-00-00 00:00:00","0000-00-00 00:00:00","2025-04-05 10:09:42","5");



DROP TABLE IF EXISTS tools;

CREATE TABLE `tools` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `facilityid` bigint NOT NULL,
  `productid` bigint NOT NULL,
  `quantity` bigint NOT NULL,
  `price` decimal(12,2) NOT NULL,
  `total` decimal(12,2) NOT NULL,
  `product_condition` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `serie` varchar(150) COLLATE utf8mb4_spanish2_ci DEFAULT NULL,
  `mac` varchar(150) COLLATE utf8mb4_spanish2_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `facilityid` (`facilityid`),
  KEY `productid` (`productid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;




DROP TABLE IF EXISTS unit;

CREATE TABLE `unit` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `code` varchar(5) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `united` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `registration_date` datetime NOT NULL,
  `state` bigint NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;

INSERT INTO unit VALUES("1","UN","UNIDAD","2022-07-07 21:03:40","1");



DROP TABLE IF EXISTS users;

CREATE TABLE `users` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `names` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `surnames` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `documentid` bigint NOT NULL,
  `document` varchar(15) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `mobile` varchar(10) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `email` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `profileid` bigint NOT NULL,
  `username` varchar(30) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `password` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `token` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `image` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `registration_date` datetime NOT NULL,
  `state` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `documentid` (`documentid`),
  KEY `profileid` (`profileid`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;

INSERT INTO users VALUES("1","admin","admin","2","04801044274","8297989774","demo1@gmail.com","1","admin","cEo0bmRLQlVpSkQ3anVScXdmb3JTUT09","","user_default.png","2022-07-07 19:39:22","1");



DROP TABLE IF EXISTS voucher_series;

CREATE TABLE `voucher_series` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `serie` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `fromc` bigint NOT NULL,
  `until` bigint NOT NULL,
  `voucherid` bigint NOT NULL,
  `available` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `voucherid` (`voucherid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;

INSERT INTO voucher_series VALUES("1","2022-07-07","R001","1","1000000","1","999951");



DROP TABLE IF EXISTS vouchers;

CREATE TABLE `vouchers` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `voucher` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `registration_date` datetime NOT NULL,
  `state` bigint NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;

INSERT INTO vouchers VALUES("1","RECIBO","2022-07-07 17:37:14","1");
INSERT INTO vouchers VALUES("2","FACTURA ELECTRONICA","2022-07-07 18:06:12","1");
INSERT INTO vouchers VALUES("3","BOLETA ELECTRONICA","2022-07-07 09:27:20","1");



DROP TABLE IF EXISTS zonas;

CREATE TABLE `zonas` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `nombre_zona` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish2_ci NOT NULL,
  `registration_date` datetime NOT NULL,
  `state` bigint NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_spanish2_ci;

INSERT INTO zonas VALUES("3","PRUEBA","2025-03-18 16:26:00","1");
INSERT INTO zonas VALUES("4","ZONA 2","2025-03-18 16:32:55","1");



SET FOREIGN_KEY_CHECKS=1;